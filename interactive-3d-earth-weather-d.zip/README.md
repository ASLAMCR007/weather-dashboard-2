# Interactive 3D Earth Weather Dashboard

Created with [Omma](https://omma.build)

## Setup

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
