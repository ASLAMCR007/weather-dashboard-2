import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// Scene setup
const scene = new THREE.Scene();
scene.name = 'mainScene';

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.name = 'mainCamera';

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.setClearColor(0x0a0e17, 1);
(document.getElementById('root') ?? document.body).appendChild(renderer.domElement);

// Controls
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.minDistance = 2.8;
controls.maxDistance = 12;
controls.enablePan = false;

// Textures
const textureLoader = new THREE.TextureLoader();
const baseURL = 'https://unpkg.com/three-globe@2.34.0/example/img/';
const earthTexture = textureLoader.load(baseURL + 'earth-blue-marble.jpg');
const earthBumpMap = textureLoader.load(baseURL + 'earth-topology.png');
const earthNightTexture = textureLoader.load(baseURL + 'earth-night.jpg');
earthTexture.colorSpace = THREE.SRGBColorSpace;
earthNightTexture.colorSpace = THREE.SRGBColorSpace;

// Lighting
const sunLight = new THREE.DirectionalLight(0xfff8f0, 4.0);
sunLight.name = 'sunLight';
sunLight.position.set(15, 10, 15);
scene.add(sunLight);

const fillLight = new THREE.DirectionalLight(0xe8eeff, 1.5);
fillLight.name = 'fillLight';
fillLight.position.set(-10, 5, 10);
scene.add(fillLight);

const ambientLight = new THREE.AmbientLight(0xc8d0e0, 1.2);
ambientLight.name = 'ambientLight';
scene.add(ambientLight);

const rimLight = new THREE.DirectionalLight(0xffffff, 1.0);
rimLight.name = 'rimLight';
rimLight.position.set(-5, 0, -15);
scene.add(rimLight);

// Earth
const EARTH_RADIUS = 2;
const earthGeometry = new THREE.SphereGeometry(EARTH_RADIUS, 128, 128);
const earthMaterial = new THREE.MeshStandardMaterial({
  map: earthTexture,
  bumpMap: earthBumpMap,
  bumpScale: 0.04,
  roughness: 0.85,
  metalness: 0.05,
  emissiveMap: earthNightTexture,
  emissive: new THREE.Color(0xffcc88),
  emissiveIntensity: 0.2,
});

const earth = new THREE.Mesh(earthGeometry, earthMaterial);
earth.name = 'earth';
scene.add(earth);

// Atmosphere glow
const atmosphereGeometry = new THREE.SphereGeometry(EARTH_RADIUS * 1.015, 64, 64);
const atmosphereMaterial = new THREE.ShaderMaterial({
  vertexShader: `
    varying vec3 vWorldNormal;
    varying vec3 vViewDir;
    void main() {
      vec4 worldPos = modelMatrix * vec4(position, 1.0);
      vWorldNormal = normalize(mat3(modelMatrix) * normal);
      vViewDir = normalize(cameraPosition - worldPos.xyz);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    varying vec3 vWorldNormal;
    varying vec3 vViewDir;
    void main() {
      float fresnel = 1.0 - max(0.0, dot(vViewDir, vWorldNormal));
      fresnel = pow(fresnel, 3.0);
      vec3 innerColor = vec3(0.35, 0.65, 1.0);
      vec3 outerColor = vec3(0.1, 0.3, 0.9);
      vec3 col = mix(innerColor, outerColor, fresnel);
      float alpha = fresnel * 0.6;
      gl_FragColor = vec4(col, alpha);
    }
  `,
  transparent: true,
  depthWrite: false,
  side: THREE.FrontSide,
  blending: THREE.AdditiveBlending
});
const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
atmosphere.name = 'earthAtmosphere';
earth.add(atmosphere);

// Outer glow
const outerGlowGeometry = new THREE.SphereGeometry(EARTH_RADIUS * 1.08, 64, 64);
const outerGlowMaterial = new THREE.ShaderMaterial({
  vertexShader: `
    varying vec3 vWorldNormal;
    varying vec3 vViewDir;
    void main() {
      vec4 worldPos = modelMatrix * vec4(position, 1.0);
      vWorldNormal = normalize(mat3(modelMatrix) * normal);
      vViewDir = normalize(cameraPosition - worldPos.xyz);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    varying vec3 vWorldNormal;
    varying vec3 vViewDir;
    void main() {
      float fresnel = 1.0 - max(0.0, dot(vViewDir, vWorldNormal));
      fresnel = pow(fresnel, 2.0);
      vec3 glowColor = vec3(0.2, 0.5, 1.0);
      float alpha = fresnel * 0.15;
      gl_FragColor = vec4(glowColor, alpha);
    }
  `,
  transparent: true,
  depthWrite: false,
  side: THREE.BackSide,
  blending: THREE.AdditiveBlending
});
const outerGlow = new THREE.Mesh(outerGlowGeometry, outerGlowMaterial);
outerGlow.name = 'earthOuterGlow';
earth.add(outerGlow);

// Stars background
const starsGeometry = new THREE.BufferGeometry();
const starsCount = 4000;
const starsPositions = new Float32Array(starsCount * 3);
const starsSizes = new Float32Array(starsCount);
for (let i = 0; i < starsCount; i++) {
  const theta = Math.random() * Math.PI * 2;
  const phi = Math.acos(2 * Math.random() - 1);
  const r = 40 + Math.random() * 60;
  starsPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
  starsPositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
  starsPositions[i * 3 + 2] = r * Math.cos(phi);
  starsSizes[i] = Math.random() * 1.5 + 0.5;
}
starsGeometry.setAttribute('position', new THREE.BufferAttribute(starsPositions, 3));
starsGeometry.setAttribute('size', new THREE.BufferAttribute(starsSizes, 1));
const starsMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.08, sizeAttenuation: true, transparent: true, opacity: 0.8 });
const stars = new THREE.Points(starsGeometry, starsMaterial);
stars.name = 'stars';
scene.add(stars);

// Location pin
const pinGroup = new THREE.Group();
pinGroup.name = 'locationPin';
pinGroup.visible = false;
scene.add(pinGroup);

const pinStemGeometry = new THREE.CylinderGeometry(0.012, 0.012, 0.15, 8);
const pinStemMaterial = new THREE.MeshStandardMaterial({ color: 0x3b82f6, emissive: 0x3b82f6, emissiveIntensity: 0.5 });
const pinStem = new THREE.Mesh(pinStemGeometry, pinStemMaterial);
pinStem.name = 'pinStem';
pinStem.position.y = 0.075;
pinGroup.add(pinStem);

const pinHeadGeometry = new THREE.SphereGeometry(0.04, 16, 16);
const pinHeadMaterial = new THREE.MeshStandardMaterial({ color: 0x3b82f6, emissive: 0x3b82f6, emissiveIntensity: 0.8 });
const pinHead = new THREE.Mesh(pinHeadGeometry, pinHeadMaterial);
pinHead.name = 'pinHead';
pinHead.position.y = 0.17;
pinGroup.add(pinHead);

// Pin pulse ring
const pulseGeometry = new THREE.RingGeometry(0.03, 0.06, 32);
const pulseMaterial = new THREE.MeshBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.6, side: THREE.DoubleSide });
const pulseRing = new THREE.Mesh(pulseGeometry, pulseMaterial);
pulseRing.name = 'pulseRing';
pulseRing.rotation.x = -Math.PI / 2;
pinGroup.add(pulseRing);

// Camera setup
camera.position.set(3, 1.5, 4.5);
controls.target.set(0, 0, 0);
controls.update();

// Raycaster
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

// Weather emoji map
const weatherEmojis = {
  0: '☀️', 1: '🌤️', 2: '⛅', 3: '☁️',
  45: '🌫️', 48: '🌫️',
  51: '🌦️', 53: '🌦️', 55: '🌧️',
  56: '🌧️', 57: '🌧️',
  61: '🌧️', 63: '🌧️', 65: '🌧️',
  66: '🌧️', 67: '🌧️',
  71: '🌨️', 73: '🌨️', 75: '❄️',
  77: '❄️',
  80: '🌦️', 81: '🌧️', 82: '🌧️',
  85: '🌨️', 86: '🌨️',
  95: '⛈️', 96: '⛈️', 99: '⛈️'
};

const weatherDescriptions = {
  0: 'Clear Sky', 1: 'Mainly Clear', 2: 'Partly Cloudy', 3: 'Overcast',
  45: 'Fog', 48: 'Depositing Rime Fog',
  51: 'Light Drizzle', 53: 'Moderate Drizzle', 55: 'Dense Drizzle',
  56: 'Freezing Drizzle', 57: 'Freezing Drizzle',
  61: 'Slight Rain', 63: 'Moderate Rain', 65: 'Heavy Rain',
  66: 'Freezing Rain', 67: 'Freezing Rain',
  71: 'Slight Snow', 73: 'Moderate Snow', 75: 'Heavy Snow',
  77: 'Snow Grains',
  80: 'Slight Showers', 81: 'Moderate Showers', 82: 'Violent Showers',
  85: 'Slight Snow Showers', 86: 'Heavy Snow Showers',
  95: 'Thunderstorm', 96: 'Thunderstorm with Hail', 99: 'Thunderstorm with Heavy Hail'
};

// Wind direction helper
function getWindDirection(deg) {
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}

// Reverse geocoding
async function getLocationName(lat, lon) {
  try {
    const resp = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&zoom=6&accept-language=en`);
    const data = await resp.json();
    if (data.address) {
      const city = data.address.city || data.address.town || data.address.village || data.address.county || '';
      const country = data.address.country || '';
      if (city && country) return `${city}, ${country}`;
      if (country) return country;
    }
    if (data.display_name) {
      const parts = data.display_name.split(',');
      return parts.slice(0, 2).join(',').trim();
    }
  } catch (e) { /* ignore */ }
  return `${lat.toFixed(1)}°${lat >= 0 ? 'N' : 'S'}, ${Math.abs(lon).toFixed(1)}°${lon >= 0 ? 'E' : 'W'}`;
}

// Fetch weather
async function fetchWeather(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,uv_index&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max&timezone=auto&forecast_days=5`;
  const resp = await fetch(url);
  return resp.json();
}

// Convert lat/lon to 3D position
function latLonToVec3(lat, lon, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

// Convert 3D point on sphere to lat/lon
function vec3ToLatLon(point, radius) {
  const normalized = point.clone().normalize();
  const lat = 90 - Math.acos(normalized.y) * (180 / Math.PI);
  let lon = Math.atan2(normalized.z, -normalized.x) * (180 / Math.PI) - 180;
  if (lon < -180) lon += 360;
  if (lon > 180) lon -= 360;
  return { lat, lon };
}

// UI Setup
const uiContainer = document.createElement('div');
uiContainer.id = 'weatherUI';
uiContainer.innerHTML = `
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    #weatherUI {
      font-family: 'Inter', -apple-system, sans-serif;
      pointer-events: none;
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      z-index: 10;
    }

    #headerBar {
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 20px;
      background: rgba(15, 20, 35, 0.7);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 50px;
      pointer-events: auto;
      z-index: 100;
    }

    #headerBar .globe-icon {
      width: 22px;
      height: 22px;
      border-radius: 50%;
      background: linear-gradient(135deg, #3b82f6, #06b6d4);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      flex-shrink: 0;
    }

    #headerBar .title {
      font-size: 13px;
      font-weight: 600;
      color: rgba(255,255,255,0.95);
      letter-spacing: -0.01em;
      white-space: nowrap;
    }

    #headerBar .divider {
      width: 1px;
      height: 16px;
      background: rgba(255,255,255,0.12);
    }

    #headerBar .hint {
      font-size: 11px;
      color: rgba(255,255,255,0.4);
      white-space: nowrap;
    }

    #searchWrapper {
      position: fixed;
      top: 16px;
      right: 16px;
      pointer-events: auto;
      z-index: 100;
    }

    #searchToggle {
      width: 38px;
      height: 38px;
      border-radius: 50%;
      background: rgba(15, 20, 35, 0.7);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.08);
      color: rgba(255,255,255,0.7);
      font-size: 15px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }

    #searchToggle:hover {
      background: rgba(30, 40, 65, 0.8);
      color: rgba(255,255,255,0.95);
    }

    #searchPanel {
      position: absolute;
      top: 46px;
      right: 0;
      width: 280px;
      background: rgba(15, 20, 35, 0.85);
      backdrop-filter: blur(30px);
      -webkit-backdrop-filter: blur(30px);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 14px;
      padding: 12px;
      display: none;
      flex-direction: column;
      gap: 8px;
    }

    #searchPanel.open { display: flex; }

    #searchInput {
      width: 100%;
      padding: 9px 12px;
      border-radius: 10px;
      border: 1px solid rgba(255,255,255,0.1);
      background: rgba(255,255,255,0.05);
      color: #fff;
      font-size: 13px;
      font-family: 'Inter', sans-serif;
      outline: none;
      transition: border-color 0.2s;
    }

    #searchInput::placeholder { color: rgba(255,255,255,0.3); }
    #searchInput:focus { border-color: rgba(59,130,246,0.5); }

    #searchResults {
      max-height: 200px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    #searchResults::-webkit-scrollbar { width: 4px; }
    #searchResults::-webkit-scrollbar-track { background: transparent; }
    #searchResults::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 2px; }

    .search-result-item {
      padding: 8px 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 12px;
      color: rgba(255,255,255,0.75);
      transition: all 0.15s;
    }

    .search-result-item:hover {
      background: rgba(255,255,255,0.08);
      color: rgba(255,255,255,0.95);
    }

    .search-result-item .sr-name {
      font-weight: 500;
      color: rgba(255,255,255,0.9);
    }

    .search-result-item .sr-detail {
      font-size: 11px;
      color: rgba(255,255,255,0.4);
      margin-top: 1px;
    }

    #weatherPanel {
      position: fixed;
      bottom: 16px;
      left: 16px;
      width: 340px;
      max-height: calc(100vh - 80px);
      overflow-y: auto;
      background: rgba(15, 20, 35, 0.8);
      backdrop-filter: blur(30px);
      -webkit-backdrop-filter: blur(30px);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 18px;
      padding: 0;
      pointer-events: auto;
      transform: translateY(20px);
      opacity: 0;
      transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      display: none;
    }

    #weatherPanel::-webkit-scrollbar { width: 4px; }
    #weatherPanel::-webkit-scrollbar-track { background: transparent; }
    #weatherPanel::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 2px; }

    #weatherPanel.visible {
      display: block;
      transform: translateY(0);
      opacity: 1;
    }

    .wp-header {
      padding: 20px 20px 0;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }

    .wp-location {
      font-size: 15px;
      font-weight: 600;
      color: rgba(255,255,255,0.95);
      letter-spacing: -0.01em;
      max-width: 240px;
      line-height: 1.3;
    }

    .wp-coords {
      font-size: 11px;
      color: rgba(255,255,255,0.35);
      font-weight: 400;
      margin-top: 3px;
      font-variant-numeric: tabular-nums;
    }

    .wp-close {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: rgba(255,255,255,0.06);
      border: none;
      color: rgba(255,255,255,0.5);
      font-size: 14px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
      flex-shrink: 0;
      margin-left: 8px;
    }

    .wp-close:hover {
      background: rgba(255,255,255,0.12);
      color: rgba(255,255,255,0.9);
    }

    .wp-current {
      padding: 16px 20px;
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .wp-temp-block {
      display: flex;
      flex-direction: column;
    }

    .wp-emoji {
      font-size: 44px;
      line-height: 1;
    }

    .wp-temp {
      font-size: 42px;
      font-weight: 700;
      color: #fff;
      letter-spacing: -0.03em;
      line-height: 1;
    }

    .wp-condition {
      font-size: 13px;
      color: rgba(255,255,255,0.55);
      font-weight: 400;
      margin-top: 4px;
    }

    .wp-feels {
      font-size: 11px;
      color: rgba(255,255,255,0.3);
      margin-top: 2px;
    }

    .wp-details {
      padding: 0 20px 16px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 8px;
    }

    .wp-detail-card {
      background: rgba(255,255,255,0.04);
      border-radius: 12px;
      padding: 10px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .wp-detail-label {
      font-size: 10px;
      color: rgba(255,255,255,0.3);
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .wp-detail-value {
      font-size: 14px;
      font-weight: 600;
      color: rgba(255,255,255,0.85);
      font-variant-numeric: tabular-nums;
    }

    .wp-detail-unit {
      font-size: 10px;
      font-weight: 400;
      color: rgba(255,255,255,0.35);
    }

    .wp-divider {
      height: 1px;
      background: rgba(255,255,255,0.06);
      margin: 0 20px;
    }

    .wp-forecast-title {
      padding: 14px 20px 8px;
      font-size: 11px;
      font-weight: 600;
      color: rgba(255,255,255,0.35);
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }

    .wp-forecast {
      padding: 0 20px 18px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .wp-forecast-row {
      display: flex;
      align-items: center;
      padding: 8px 10px;
      border-radius: 10px;
      transition: background 0.15s;
    }

    .wp-forecast-row:hover {
      background: rgba(255,255,255,0.04);
    }

    .wp-forecast-day {
      font-size: 12px;
      font-weight: 500;
      color: rgba(255,255,255,0.7);
      width: 40px;
    }

    .wp-forecast-emoji {
      font-size: 18px;
      width: 32px;
      text-align: center;
    }

    .wp-forecast-desc {
      font-size: 11px;
      color: rgba(255,255,255,0.4);
      flex: 1;
      padding: 0 8px;
    }

    .wp-forecast-temps {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-variant-numeric: tabular-nums;
    }

    .wp-forecast-hi {
      color: rgba(255,255,255,0.85);
      font-weight: 600;
    }

    .wp-forecast-lo {
      color: rgba(255,255,255,0.35);
      font-weight: 400;
    }

    .wp-forecast-precip {
      font-size: 10px;
      color: rgba(100,180,255,0.6);
      width: 36px;
      text-align: right;
    }

    #loadingOverlay {
      position: fixed;
      bottom: 16px;
      left: 16px;
      padding: 14px 22px;
      background: rgba(15, 20, 35, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 14px;
      display: none;
      align-items: center;
      gap: 10px;
      pointer-events: none;
      z-index: 50;
    }

    #loadingOverlay.active { display: flex; }

    .loading-spinner {
      width: 16px;
      height: 16px;
      border: 2px solid rgba(255,255,255,0.1);
      border-top-color: #3b82f6;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }

    @keyframes spin { to { transform: rotate(360deg); } }

    .loading-text {
      font-size: 12px;
      color: rgba(255,255,255,0.6);
    }

    #tooltip {
      position: fixed;
      padding: 6px 12px;
      background: rgba(15, 20, 35, 0.85);
      backdrop-filter: blur(15px);
      -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px;
      font-family: 'Inter', sans-serif;
      font-size: 11px;
      color: rgba(255,255,255,0.7);
      pointer-events: none;
      display: none;
      z-index: 200;
      white-space: nowrap;
    }

    canvas { cursor: grab; }
    canvas:active { cursor: grabbing; }
  </style>

  <div id="headerBar">
    <div class="globe-icon">🌍</div>
    <span class="title">Weather Globe</span>
    <div class="divider"></div>
    <span class="hint">Click anywhere on Earth</span>
  </div>

  <div id="searchWrapper">
    <button id="searchToggle">🔍</button>
    <div id="searchPanel">
      <input id="searchInput" type="text" placeholder="Search city or place..." autocomplete="off" />
      <div id="searchResults"></div>
    </div>
  </div>

  <div id="loadingOverlay">
    <div class="loading-spinner"></div>
    <span class="loading-text">Fetching weather data...</span>
  </div>

  <div id="weatherPanel"></div>
  <div id="tooltip"></div>
`;
document.body.appendChild(uiContainer);

// Search functionality
const searchToggle = document.getElementById('searchToggle');
const searchPanel = document.getElementById('searchPanel');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
let searchTimeout;

searchToggle.addEventListener('click', () => {
  searchPanel.classList.toggle('open');
  if (searchPanel.classList.contains('open')) {
    searchInput.focus();
  }
});

document.addEventListener('click', (e) => {
  if (!document.getElementById('searchWrapper').contains(e.target)) {
    searchPanel.classList.remove('open');
  }
});

searchInput.addEventListener('input', () => {
  clearTimeout(searchTimeout);
  const query = searchInput.value.trim();
  if (query.length < 2) { searchResults.innerHTML = ''; return; }
  searchTimeout = setTimeout(async () => {
    try {
      const resp = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=6&language=en`);
      const data = await resp.json();
      searchResults.innerHTML = '';
      if (data.results) {
        data.results.forEach(r => {
          const item = document.createElement('div');
          item.className = 'search-result-item';
          item.innerHTML = `
            <div class="sr-name">${r.name}</div>
            <div class="sr-detail">${[r.admin1, r.country].filter(Boolean).join(', ')}</div>
          `;
          item.addEventListener('click', () => {
            selectLocation(r.latitude, r.longitude);
            searchPanel.classList.remove('open');
            searchInput.value = '';
            searchResults.innerHTML = '';
          });
          searchResults.appendChild(item);
        });
      }
    } catch (e) { /* ignore */ }
  }, 300);
});

// Tooltip
const tooltip = document.getElementById('tooltip');
let isHoveringEarth = false;

renderer.domElement.addEventListener('mousemove', (e) => {
  mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObject(earth, false);
  if (intersects.length > 0) {
    isHoveringEarth = true;
    renderer.domElement.style.cursor = 'pointer';
    const point = intersects[0].point;
    const localPoint = earth.worldToLocal(point.clone());
    const { lat, lon } = vec3ToLatLon(localPoint, EARTH_RADIUS);
    tooltip.style.display = 'block';
    tooltip.style.left = (e.clientX + 14) + 'px';
    tooltip.style.top = (e.clientY - 10) + 'px';
    tooltip.textContent = `${lat.toFixed(1)}°${lat >= 0 ? 'N' : 'S'}, ${Math.abs(lon).toFixed(1)}°${lon >= 0 ? 'E' : 'W'}`;
  } else {
    isHoveringEarth = false;
    renderer.domElement.style.cursor = 'grab';
    tooltip.style.display = 'none';
  }
});

renderer.domElement.addEventListener('mouseleave', () => {
  tooltip.style.display = 'none';
});

// Click handler
let isDragging = false;
let mouseDownPos = { x: 0, y: 0 };

renderer.domElement.addEventListener('mousedown', (e) => {
  mouseDownPos.x = e.clientX;
  mouseDownPos.y = e.clientY;
  isDragging = false;
});

renderer.domElement.addEventListener('mousemove', (e) => {
  const dx = e.clientX - mouseDownPos.x;
  const dy = e.clientY - mouseDownPos.y;
  if (Math.sqrt(dx * dx + dy * dy) > 5) isDragging = true;
});

renderer.domElement.addEventListener('mouseup', (e) => {
  if (isDragging) return;
  mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObject(earth, false);
  if (intersects.length > 0) {
    const point = intersects[0].point;
    const localPoint = earth.worldToLocal(point.clone());
    const { lat, lon } = vec3ToLatLon(localPoint, EARTH_RADIUS);
    selectLocation(lat, lon);
  }
});

// Touch support
let touchStartPos = { x: 0, y: 0 };
let touchMoved = false;

renderer.domElement.addEventListener('touchstart', (e) => {
  if (e.touches.length === 1) {
    touchStartPos.x = e.touches[0].clientX;
    touchStartPos.y = e.touches[0].clientY;
    touchMoved = false;
  }
}, { passive: true });

renderer.domElement.addEventListener('touchmove', (e) => {
  if (e.touches.length === 1) {
    const dx = e.touches[0].clientX - touchStartPos.x;
    const dy = e.touches[0].clientY - touchStartPos.y;
    if (Math.sqrt(dx * dx + dy * dy) > 10) touchMoved = true;
  }
}, { passive: true });

renderer.domElement.addEventListener('touchend', (e) => {
  if (touchMoved) return;
  const touch = e.changedTouches[0];
  mouse.x = (touch.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(touch.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObject(earth, false);
  if (intersects.length > 0) {
    const point = intersects[0].point;
    const localPoint = earth.worldToLocal(point.clone());
    const { lat, lon } = vec3ToLatLon(localPoint, EARTH_RADIUS);
    selectLocation(lat, lon);
  }
});

// Select location and show weather
async function selectLocation(lat, lon) {
  const loading = document.getElementById('loadingOverlay');
  const panel = document.getElementById('weatherPanel');

  // Place pin
  const pos = latLonToVec3(lat, lon, EARTH_RADIUS);
  pinGroup.position.copy(pos);
  pinGroup.lookAt(pos.clone().multiplyScalar(2));
  pinGroup.visible = true;

  // Show loading
  loading.classList.add('active');
  panel.classList.remove('visible');

  try {
    const [weather, locationName] = await Promise.all([
      fetchWeather(lat, lon),
      getLocationName(lat, lon)
    ]);

    const current = weather.current;
    const daily = weather.daily;
    const code = current.weather_code;
    const emoji = weatherEmojis[code] || '🌡️';
    const desc = weatherDescriptions[code] || 'Unknown';

    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    let forecastHTML = '';
    for (let i = 1; i < Math.min(daily.time.length, 6); i++) {
      const d = new Date(daily.time[i] + 'T00:00:00');
      const dayName = i === 1 ? 'Tmrw' : dayNames[d.getDay()];
      const dCode = daily.weather_code[i];
      const dEmoji = weatherEmojis[dCode] || '🌡️';
      const dDesc = weatherDescriptions[dCode] || '';
      const precip = daily.precipitation_probability_max?.[i];
      forecastHTML += `
        <div class="wp-forecast-row">
          <span class="wp-forecast-day">${dayName}</span>
          <span class="wp-forecast-emoji">${dEmoji}</span>
          <span class="wp-forecast-desc">${dDesc}</span>
          <div class="wp-forecast-temps">
            <span class="wp-forecast-lo">${Math.round(daily.temperature_2m_min[i])}°</span>
            <span class="wp-forecast-hi">${Math.round(daily.temperature_2m_max[i])}°</span>
          </div>
          <span class="wp-forecast-precip">${precip != null ? precip + '%' : ''}</span>
        </div>
      `;
    }

    panel.innerHTML = `
      <div class="wp-header">
        <div>
          <div class="wp-location">${locationName}</div>
          <div class="wp-coords">${Math.abs(lat).toFixed(2)}°${lat >= 0 ? 'N' : 'S'}, ${Math.abs(lon).toFixed(2)}°${lon >= 0 ? 'E' : 'W'}</div>
        </div>
        <button class="wp-close" onclick="document.getElementById('weatherPanel').classList.remove('visible'); document.querySelector('[name=locationPin]') && (document.querySelector('[name=locationPin]').visible = false);">✕</button>
      </div>

      <div class="wp-current">
        <span class="wp-emoji">${emoji}</span>
        <div class="wp-temp-block">
          <span class="wp-temp">${Math.round(current.temperature_2m)}°</span>
          <span class="wp-condition">${desc}</span>
          <span class="wp-feels">Feels like ${Math.round(current.apparent_temperature)}°</span>
        </div>
      </div>

      <div class="wp-details">
        <div class="wp-detail-card">
          <span class="wp-detail-label">Wind</span>
          <span class="wp-detail-value">${Math.round(current.wind_speed_10m)} <span class="wp-detail-unit">km/h</span></span>
          <span class="wp-detail-unit">${getWindDirection(current.wind_direction_10m)}</span>
        </div>
        <div class="wp-detail-card">
          <span class="wp-detail-label">Humidity</span>
          <span class="wp-detail-value">${current.relative_humidity_2m}<span class="wp-detail-unit">%</span></span>
        </div>
        <div class="wp-detail-card">
          <span class="wp-detail-label">Pressure</span>
          <span class="wp-detail-value">${Math.round(current.pressure_msl)} <span class="wp-detail-unit">hPa</span></span>
        </div>
        <div class="wp-detail-card">
          <span class="wp-detail-label">Cloud</span>
          <span class="wp-detail-value">${current.cloud_cover}<span class="wp-detail-unit">%</span></span>
        </div>
        <div class="wp-detail-card">
          <span class="wp-detail-label">UV Index</span>
          <span class="wp-detail-value">${current.uv_index != null ? current.uv_index.toFixed(1) : '—'}</span>
        </div>
        <div class="wp-detail-card">
          <span class="wp-detail-label">High/Low</span>
          <span class="wp-detail-value">${Math.round(daily.temperature_2m_max[0])}°<span class="wp-detail-unit"> / ${Math.round(daily.temperature_2m_min[0])}°</span></span>
        </div>
      </div>

      <div class="wp-divider"></div>
      <div class="wp-forecast-title">5-Day Forecast</div>
      <div class="wp-forecast">${forecastHTML}</div>
    `;

    panel.querySelector('.wp-close').addEventListener('click', () => {
      panel.classList.remove('visible');
      pinGroup.visible = false;
    });

    loading.classList.remove('active');
    // Trigger reflow then add visible class
    void panel.offsetWidth;
    panel.classList.add('visible');

  } catch (err) {
    console.error('Weather fetch error:', err);
    loading.classList.remove('active');
    panel.innerHTML = `
      <div class="wp-header">
        <div>
          <div class="wp-location">Error</div>
          <div class="wp-coords">Could not fetch weather data</div>
        </div>
        <button class="wp-close">✕</button>
      </div>
      <div style="padding: 20px; color: rgba(255,255,255,0.5); font-size: 13px;">
        Unable to load weather for this location. Please try again.
      </div>
    `;
    panel.querySelector('.wp-close').addEventListener('click', () => {
      panel.classList.remove('visible');
      pinGroup.visible = false;
    });
    void panel.offsetWidth;
    panel.classList.add('visible');
  }
}

// Clouds layer
const cloudsGeometry = new THREE.SphereGeometry(EARTH_RADIUS * 1.005, 64, 64);
const cloudsMaterial = new THREE.MeshStandardMaterial({
  alphaMap: textureLoader.load(baseURL + 'earth-water.png'),
  transparent: true,
  opacity: 0.12,
  color: 0xffffff,
  depthWrite: false,
});
const clouds = new THREE.Mesh(cloudsGeometry, cloudsMaterial);
clouds.name = 'cloudsLayer';
earth.add(clouds);

// Animation
const clock = new THREE.Clock();
let pinPulseTime = 0;

function animate() {
  const elapsed = clock.getElapsedTime();

  // Slow earth rotation
  earth.rotation.y = elapsed * 0.03;
  clouds.rotation.y = elapsed * 0.008;

  // Pin animation
  if (pinGroup.visible) {
    pinPulseTime += 0.03;
    const scale = 1 + Math.sin(pinPulseTime * 2) * 0.15;
    pulseRing.scale.set(scale, scale, 1);
    pulseMaterial.opacity = 0.6 - Math.sin(pinPulseTime * 2) * 0.3;
    pinHead.position.y = 0.17 + Math.sin(pinPulseTime * 3) * 0.008;
  }

  // Twinkle stars
  stars.rotation.y = elapsed * 0.002;

  controls.update();
  renderer.render(scene, camera);
}
renderer.setAnimationLoop(animate);

// Handle resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});